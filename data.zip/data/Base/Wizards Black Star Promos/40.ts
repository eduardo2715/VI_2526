import { Card } from '../../../interfaces'
import Set from '../Wizards Black Star Promos'

const card: Card = {
	name: {
		en: "Pokémon Center",
	},
	illustrator: undefined,
	rarity: "Common",
	category: "Trainer",

	set: Set,














}

export default card
